#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{   
    int parent_pid = getpid();
    int x=54,y=39,z=10;

    printf(1, "parent id %d\n",parent_pid);

    // Set the scheduling policy to EDF
    // printf(1,"deadline %d\n",deadline(parent_pid, 25));
    // printf(1,"exec_time %d\n",exec_time(parent_pid, 10));
    // printf(1,"sched_policy %d\n",sched_policy(parent_pid, 0));

    printf(1,"sched_policy %d\n",sched_policy(parent_pid, 0));
    printf(1,"yo %d\n",x);
    printf(1,"hello %d\n",y);
    printf(1,"dfd %d\n",z);

    exit();

}
