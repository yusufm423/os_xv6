#!/bin/bash

# Check if the directory exists
if [ -d "check_scripts" ]; then
    # Remove the directory
    rm -r "check_scripts"
    echo "Directory 'check_scripts' has been deleted."
else
    echo "Directory 'check_scripts' does not exist."
fi

# Check if the tarball exists
if [ -f "assignment2_easy_2023eet2757_2023eet2193.tar.gz" ]; then
    # Remove the tarball
    rm "assignment2_easy_2023eet2757_2023eet2193.tar.gz"
    echo "Tarball 'assignment2_easy_2023eet2757_2023eet2193.tar.gz' has been deleted."
else
    echo "Tarball 'assignment2_easy_2023eet2757_2023eet2193.tar.gz' does not exist."
fi

# Clean up the build
make clean

# Create a tarball of the current directory
tar czvf assignment2_easy_2023eet2757_2023eet2193.tar.gz *

# Create a directory for the check scripts
mkdir check_scripts

# Extract the check scripts into the new directory
tar xzvf check_scripts.tar.gz -C check_scripts

# Copy the tarball into the check scripts directory
cp assignment2_easy_2023eet2757_2023eet2193.tar.gz \check_scripts

# Change to the check scripts directory
cd check_scripts

# Run the check script with the tarball as an argument
bash check.sh \assignment2_easy_2023eet2757_2023eet2193.tar.gz

